<?php

/**
 * Core file
 *
 * A class for run actions & filters
 *
 * @package UltraEmbed
 * @since 1.0.0
 */
if (!class_exists('ultraEmbedInit')) {
	/**
	 * this class will handle all  hooks
	 */
	class ultraEmbedInit
	{
		
		function run()
		{

			//plugins loaded hook
			add_action('plugins_loaded', array($this,'loaded'), 0);

			//register shortcode
			add_shortcode('iframe',array($this,'iframeView'));
		}
		public function iframeView($atts,$content=null)
		{
			//validing all attribute
			$atts = shortcode_atts(
				array(
					'login' => false,
					'src' => '',
					'width' => '',
					'height' => '',
					'class' => '',
					'style' => '',
			),$atts);

			$login = $atts['login'];

			//removing login attr
			unset($atts['login']);
			if (isset($atts['src']) && !empty($atts['src'])) {
				$attr='';
				foreach ($atts as $name => $value) {
					if (isset($value) && !empty($value)) {
						$attr .= $name.'="'.$value.'" ';
					}
				} 
				$html = "<iframe $attr></iframe>"; 
			}
			//checking need log in or not
			if ($login !== false) {
				if ( is_user_logged_in()) {
					return $html;
				}
				return ;
			}
			else{
				return $html;
			}
		}
		public function loaded()
		{
			//hook for show links after plugin activation
			add_filter('plugin_action_links_' . ultraembed_base, array($this,'settings_link'));
		}
		public function settings_link($links)
		{
			$pluginLinks = array(
	            'donate' => '<a href="https://www.buymeacoffee.com/sohagsrz" target="_blank">Donate</a>',
	            'support'     => '<a href="https://ultradevs.com/" target="blank">Support</a>'
	        );
		    $links = array_merge($links, $pluginLinks);
		    return $links;
		}
	} #class end
} #class check 
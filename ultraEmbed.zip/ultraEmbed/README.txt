=== UltraEmbed (Advanced Iframe For Wordpress) ===
Contributors: ultradevs, mhimon, sohagislam
Donate link: https://ultradevs.com/donate/
Tags: embed iframe, iframe by shortcode, iframe with condtion,iframe for logged user,iframe for all user
Requires at least: 4.4
Tested up to: 5.5
Stable tag: 1.0.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

UltraEmbed (Advanced Iframe For Wordpress).

== Description ==

UltraEmbed for wordpress. It has some advanced features that will help you to manage iframe(<iframe>) call easily

### Usage

Simply use [iframe] shortcode with src attribut.Example [iframe src="https://ultradevs.com"]
you can also use other parameter (width,height,style,class).
-- width
for set width (ex width="100%")

-- height
for set height (ex height="100%")

-- style
for add css style (ex style="overfollow:hidden;height:220px;")

-- class
for add css class (ex class="ultraframe")

-- login
it will show iframe data for logged in user.Default is false (ex login="true")


### Features

* Set width, height, class and style
* set for logged or all user seprately 
* And many more...
 

[Like Our Facebook Page](https://web.facebook.com/hello.ultradevs/)
[Join Our Facebook Group](https://web.facebook.com/groups/ultraDevs)
[Subscribe Our Youtube Channel](https://www.youtube.com/channel/UCc2yL-QGQjscXpPx9Pp7J8w?sub_confirmation=1)

 
Made with love by [SohagSrz](https://ultradevs.com) from [ultraDevs](https://ultradevs.com)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3.use shortcode [iframe src="link"]


== Frequently Asked Questions ==

= Is it possible to set condtion for logged user? =

yes you can set for logged user by use login="true" attribute on shortcode.


== Changelog ==
 
= 1.0.0 - 08/29/2020 =
* Initial Stable Release